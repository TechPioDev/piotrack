var A=Object.defineProperty;var H=(u,d,f)=>d in u?A(u,d,{enumerable:!0,configurable:!0,writable:!0,value:f}):u[d]=f;var c=(u,d,f)=>H(u,typeof d!="symbol"?d+"":d,f);(function(){"use strict";var L;const d=o=>new Promise(e=>setTimeout(e,o));async function f(o,e=700){let t;try{t=await o()}catch{return await d(e),o()}return t.status>=500?(await d(e),o()):t}const y="piotrack_chat_seen";function w(o){const e=location.pathname;return o.some(t=>{const i=t.trim();if(!i)return!1;if(i.includes("*")){const s=i.split("*").map(r=>r.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")).join(".*");return new RegExp("^"+s+"$").test(e)}return e===i||e.startsWith(i.endsWith("/")?i:i+"/")})}function _(o){if(!o)return!0;if(o.include.length>0&&!w(o.include)||o.exclude.length>0&&w(o.exclude))return!1;if(o.devices.length>0){const e=window.matchMedia("(max-width: 767px)").matches;if(!o.devices.includes(e?"mobile":"desktop"))return!1}if(o.visitor==="first"||o.visitor==="returning"){let e=!1;try{e=localStorage.getItem(y)==="1",localStorage.setItem(y,"1")}catch{}if(o.visitor==="first"&&e||o.visitor==="returning"&&!e)return!1}return!0}function P(o){if(!o)return Promise.resolve();const e=o.scroll_percent>0,t=o.exit_intent,i=Math.max(0,o.delay_seconds)*1e3;return!e&&!t?i===0?Promise.resolve():new Promise(s=>setTimeout(s,i)):new Promise(s=>{let r=!1;const h=()=>{r||(r=!0,window.removeEventListener("scroll",p),document.removeEventListener("mouseout",n),s())},p=()=>{const a=document.documentElement.scrollHeight-window.innerHeight;(a>0?window.scrollY/a*100:100)>=o.scroll_percent&&h()},n=a=>{a.relatedTarget===null&&a.clientY<=0&&h()};e&&window.addEventListener("scroll",p,{passive:!0}),t&&document.addEventListener("mouseout",n),i>0&&setTimeout(h,i)})}const m=document.currentScript,k=(L=m==null?void 0:m.dataset.widget)!=null?L:"",N=m?new URL(m.src,location.href).origin:location.origin,E="piotrack_chat_visitor",S="piotrack_chat_state";function I(){try{let o=localStorage.getItem(E);return o||(o="v_"+Math.random().toString(36).slice(2)+Date.now().toString(36),localStorage.setItem(E,o)),o}catch{return"v_anon"}}async function g(o,e){const t=await f(()=>fetch(`${N}/wc/${k}/${o}`,{method:e===void 0?"GET":"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:e===void 0?void 0:JSON.stringify(e)}));if(!t.ok)throw Object.assign(new Error("request failed"),{status:t.status,payload:await t.json().catch(()=>({}))});return t.json()}const M=o=>`
:host { all: initial; }
*, *::before, *::after { box-sizing: border-box; }
.root {
    position: fixed; z-index: 2147483000; bottom: 20px;
    font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
    color: #0b1a23; line-height: 1.5;
}
.root.left { left: 20px; } .root.right { right: 20px; }
button { font: inherit; cursor: pointer; }

/* Launcher */
.launcher {
    display: flex; align-items: center; justify-content: center;
    width: 60px; height: 60px; border-radius: 50%; border: 0;
    background: ${o}; color: #fff;
    box-shadow: 0 8px 24px -6px rgba(11,26,35,.4);
    transition: transform .18s ease, box-shadow .18s ease;
}
.launcher:hover { transform: translateY(-2px); box-shadow: 0 12px 28px -6px rgba(11,26,35,.45); }
.launcher:focus-visible { outline: 3px solid ${o}; outline-offset: 3px; }
.launcher svg { width: 26px; height: 26px; }

/* Teaser */
.teaser {
    position: absolute; bottom: 74px; width: max-content; max-width: 260px;
    background: #fff; border: 1px solid #dbe8e8; border-radius: 14px;
    padding: 12px 36px 12px 14px; font-size: 14px; font-weight: 500;
    box-shadow: 0 12px 30px -12px rgba(11,26,35,.35);
    animation: pop .25s ease;
}
.root.right .teaser { right: 0; } .root.left .teaser { left: 0; }
.teaser-close {
    position: absolute; top: 6px; right: 6px; width: 22px; height: 22px;
    border: 0; background: transparent; color: #6b8792; border-radius: 6px; line-height: 1;
}
.teaser-close:hover { background: #eef4f4; }

/* Panel */
.panel {
    position: absolute; bottom: 74px; width: 372px; max-height: min(620px, calc(100vh - 120px));
    display: flex; flex-direction: column; overflow: hidden;
    background: #fff; border: 1px solid #dbe8e8; border-radius: 18px;
    box-shadow: 0 24px 60px -20px rgba(11,26,35,.45);
    animation: pop .22s ease;
}
.root.right .panel { right: 0; } .root.left .panel { left: 0; }
@keyframes pop { from { opacity: 0; transform: translateY(10px) scale(.98); } to { opacity: 1; transform: none; } }
@media (prefers-reduced-motion: reduce) { .panel, .teaser { animation: none; } .launcher { transition: none; } }

.head { display: flex; align-items: center; gap: 10px; padding: 14px 16px; background: ${o}; color: #fff; }
.avatar {
    width: 34px; height: 34px; border-radius: 50%; flex: 0 0 auto;
    background: rgba(255,255,255,.22); display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 13px;
}
.head-text { min-width: 0; }
.head-title { font-weight: 700; font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.head-sub { font-size: 12px; opacity: .85; }
.head-close { margin-left: auto; width: 30px; height: 30px; border: 0; border-radius: 8px; background: transparent; color: #fff; font-size: 18px; line-height: 1; }
.head-close:hover { background: rgba(255,255,255,.18); }
.head-close:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }

.log { flex: 1 1 auto; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 10px; background: #f7fbfb; }
.msg { max-width: 85%; padding: 10px 13px; border-radius: 14px; font-size: 14px; white-space: pre-wrap; overflow-wrap: anywhere; }
.msg.bot { background: #fff; border: 1px solid #e6eeee; border-bottom-left-radius: 4px; align-self: flex-start; }
.msg.visitor { background: ${o}; color: #fff; border-bottom-right-radius: 4px; align-self: flex-end; }
.typing { align-self: flex-start; display: flex; gap: 4px; padding: 12px 14px; background: #fff; border: 1px solid #e6eeee; border-radius: 14px; }
.typing i { width: 6px; height: 6px; border-radius: 50%; background: #9db3bb; animation: blink 1.2s infinite; }
.typing i:nth-child(2) { animation-delay: .2s; } .typing i:nth-child(3) { animation-delay: .4s; }
@keyframes blink { 0%,60%,100% { opacity: .3; } 30% { opacity: 1; } }

.foot { border-top: 1px solid #e6eeee; padding: 12px; background: #fff; display: flex; flex-direction: column; gap: 8px; }
.choice {
    text-align: left; width: 100%; padding: 11px 13px; font-size: 14px; font-weight: 600;
    background: #fff; color: ${o}; border: 1.5px solid #d6e6e4; border-radius: 11px;
    transition: background .15s ease, border-color .15s ease;
}
.choice:hover { background: #f0faf8; border-color: ${o}; }
.choice:focus-visible { outline: 2px solid ${o}; outline-offset: 2px; }
.row { display: flex; gap: 8px; }
.row input {
    flex: 1 1 auto; min-width: 0; padding: 11px 13px; font-size: 14px;
    border: 1.5px solid #d6e6e4; border-radius: 11px; background: #fff; color: inherit;
}
.row input:focus { outline: 2px solid ${o}; outline-offset: -1px; border-color: ${o}; }
.send { flex: 0 0 auto; padding: 0 16px; border: 0; border-radius: 11px; background: ${o}; color: #fff; font-weight: 700; }
.send:disabled { opacity: .55; cursor: not-allowed; }
.skip { border: 0; background: transparent; color: #6b8792; font-size: 13px; text-decoration: underline; padding: 2px; align-self: flex-start; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
.chip {
    border: 1px solid ${o}55; background: #fff; color: ${o};
    border-radius: 999px; padding: 6px 12px; font-size: 13px; cursor: pointer;
}
.chip:hover { background: ${o}11; }
.err { color: #c02a1b; font-size: 13px; }
.consent { font-size: 12.5px; color: #5b7480; }
.consent a { color: ${o}; }
.brand { text-align: center; font-size: 11px; color: #8aa2ab; padding: 2px 0 0; }
.cta { display: block; text-align: center; padding: 11px; border-radius: 11px; background: ${o}; color: #fff; font-weight: 700; font-size: 14px; text-decoration: none; }

@media (max-width: 480px) {
    .root { bottom: 16px; }
    .root.left { left: 16px; } .root.right { right: 16px; }
    .panel {
        position: fixed; inset: 0; width: 100vw; max-height: 100vh; height: 100dvh;
        border-radius: 0; border: 0;
    }
}
`;class z{constructor(e){c(this,"root");c(this,"el");c(this,"log");c(this,"foot");c(this,"panel",null);c(this,"token",null);c(this,"open",!1);c(this,"busy",!1);c(this,"live",!1);c(this,"lastSeenId",0);c(this,"pollTimer",null);c(this,"openTracked",!1);this.config=e}mount(){const e=document.createElement("div");e.setAttribute("data-piotrack-chat",""),document.body.appendChild(e),this.root=e.attachShadow({mode:"open"});const t=document.createElement("style");t.textContent=M(this.config.theme.accent),this.root.appendChild(t),this.el=document.createElement("div"),this.el.className=`root ${this.config.theme.position==="bottom-left"?"left":"right"}`,this.root.appendChild(this.el),this.renderLauncher(),this.track("impression"),this.maybeTeaser()}renderLauncher(){const e=document.createElement("button");e.className="launcher",e.setAttribute("aria-label",`Open chat with ${this.config.theme.company}`),e.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 8.9 8.9 0 0 1-3.8-.8L3 21l1.9-5A8.4 8.4 0 0 1 12 3.1a8.4 8.4 0 0 1 9 8.4z"/></svg>',e.addEventListener("click",()=>this.toggle()),this.el.appendChild(e)}maybeTeaser(){var e;if(this.config.teaser){try{if(sessionStorage.getItem(S)==="seen")return}catch{}setTimeout(()=>{if(this.open)return;const t=document.createElement("div");t.className="teaser",t.setAttribute("role","status");const i=document.createElement("span");i.textContent=this.config.teaser;const s=document.createElement("button");s.className="teaser-close",s.setAttribute("aria-label","Dismiss message"),s.textContent="×",s.addEventListener("click",r=>{r.stopPropagation(),t.remove()}),t.append(i,s),t.addEventListener("click",()=>{t.remove(),this.toggle()}),this.el.appendChild(t);try{sessionStorage.setItem(S,"seen")}catch{}},Math.max(0,(e=this.config.teaser_delay)!=null?e:4)*1e3)}}toggle(){this.open?this.close():this.openPanel()}close(){var e,t;this.open=!1,this.stopPolling(),(e=this.panel)==null||e.remove(),this.panel=null,(t=this.el.querySelector(".launcher"))==null||t.focus()}async openPanel(){var i,s;this.open=!0,(i=this.el.querySelector(".teaser"))==null||i.remove();const e=document.createElement("div");e.className="panel",e.setAttribute("role","dialog"),e.setAttribute("aria-modal","false"),e.setAttribute("aria-label",`Chat with ${this.config.theme.company}`);const t=this.config.theme.company.trim().slice(0,2).toUpperCase();e.innerHTML=`
            <div class="head">
                <div class="avatar" aria-hidden="true">${C(t)}</div>
                <div class="head-text">
                    <div class="head-title">${C(this.config.theme.title)}</div>
                    <div class="head-sub">Typically replies in a few minutes</div>
                </div>
                <button class="head-close" aria-label="Close chat">×</button>
            </div>
            <div class="log" role="log" aria-live="polite" aria-atomic="false"></div>
            <div class="foot"></div>
        `,this.el.appendChild(e),this.panel=e,this.log=e.querySelector(".log"),this.foot=e.querySelector(".foot"),(s=e.querySelector(".head-close"))==null||s.addEventListener("click",()=>this.close()),e.addEventListener("keydown",r=>{r.key==="Escape"&&this.close()}),this.openTracked||(this.openTracked=!0,this.track("open")),this.token===null?await this.begin():await this.restore()}async restore(){var e;this.typing(!0);try{const t=await g(`conversations/${this.token}/poll?since=0`);this.typing(!1),((e=t.messages)!=null?e:[]).forEach(i=>{this.lastSeenId=Math.max(this.lastSeenId,i.id),this.bubble("bot",i.body)}),t.live&&!t.closed?(this.live=!0,this.startPolling(),this.renderLiveComposer()):t.closed?this.brand():this.renderLiveComposer()}catch{this.fail()}}renderLiveComposer(){this.foot.innerHTML="";const e=document.createElement("div");e.className="row";const t=document.createElement("input");t.type="text",t.setAttribute("aria-label","Type a message"),t.placeholder="Type your message…";const i=document.createElement("button");i.className="send",i.textContent="Send";const s=()=>{const r=t.value.trim();r&&(t.value="",this.send({value:r},r))};i.addEventListener("click",s),t.addEventListener("keydown",r=>{r.key==="Enter"&&s()}),e.append(t,i),this.foot.appendChild(e),this.brand()}async begin(){this.typing(!0);try{const e=new URLSearchParams(location.search),t={};["source","medium","campaign","term","content"].forEach(s=>{const r=e.get(`utm_${s}`);r&&(t[s]=r)});const i=await g("conversations",{visitor:I(),page:location.href.slice(0,500),referrer:document.referrer.slice(0,500),utm:t});this.token=i.token,this.render(i)}catch{this.fail()}}async send(e,t){var i,s;if(!(this.busy||!this.token)){this.busy=!0,this.bubble("visitor",t),this.foot.innerHTML="",this.typing(!0);try{const r=await g(`conversations/${this.token}/messages`,e);this.render(r)}catch(r){const h=r.status,p=r.payload;if(this.typing(!1),h===422&&(p!=null&&p.errors)){const n=(s=(i=Object.values(p.errors)[0])==null?void 0:i[0])!=null?s:"Please check that answer.";this.error(n)}else this.fail()}finally{this.busy=!1}}}startPolling(){this.pollTimer!==null||!this.token||(this.pollTimer=window.setInterval(()=>void this.poll(),4e3))}stopPolling(){this.pollTimer!==null&&(window.clearInterval(this.pollTimer),this.pollTimer=null)}async poll(){var e;if(!(!this.token||!this.open))try{const t=await g(`conversations/${this.token}/poll?since=${this.lastSeenId}`);((e=t.messages)!=null?e:[]).forEach(i=>{this.lastSeenId=Math.max(this.lastSeenId,i.id),this.bubble("bot",i.body)}),t.closed&&this.stopPolling()}catch{}}render(e){var i,s,r,h,p;if(this.typing(!1),((i=e.messages)!=null?i:[]).forEach(n=>{typeof n.id=="number"&&(this.lastSeenId=Math.max(this.lastSeenId,n.id)),this.bubble("bot",n.body)}),this.foot.innerHTML="",e.booking_url){const n=document.createElement("a");n.className="cta",n.href=e.booking_url,n.target="_blank",n.rel="noopener noreferrer",n.textContent="Choose a time",this.foot.appendChild(n)}if(e.live){this.live=!0,this.startPolling();const n=(s=this.panel)==null?void 0:s.querySelector(".head-sub");n&&(n.textContent=e.agent?`${e.agent} is here to help`:"Connected to our team")}const t=e.node;if(!t){this.stopPolling(),this.brand();return}if(t.type==="choice"||t.type==="consent"){if(t.type==="consent"){const n=document.createElement("div");if(n.className="consent",t.privacy_url){const a=document.createElement("a");a.href=t.privacy_url,a.target="_blank",a.rel="noopener noreferrer",a.textContent="Privacy Policy",n.append("See our ",a,".")}else n.textContent="Your details are only used to respond to this enquiry.";this.foot.appendChild(n)}((r=t.options)!=null?r:[]).forEach(n=>{const a=document.createElement("button");a.className="choice",a.textContent=n.label,a.addEventListener("click",()=>this.send({option:n.id},n.label)),this.foot.appendChild(a)}),(h=this.foot.querySelector(".choice"))==null||h.focus()}if(t.type==="input"){if((p=t.suggestions)!=null&&p.length){const l=document.createElement("div");l.className="chips",t.suggestions.slice(0,4).forEach(v=>{const x=document.createElement("button");x.className="chip",x.textContent=v,x.addEventListener("click",()=>this.send({value:v},v)),l.appendChild(x)}),this.foot.appendChild(l)}const n=document.createElement("div");n.className="row";const a=document.createElement("input");a.type=t.input==="email"?"email":t.input==="phone"?"tel":t.input==="number"?"number":"text",a.setAttribute("aria-label",t.text),a.placeholder="Type your answer…";const b=document.createElement("button");b.className="send",b.textContent="Send";const $=()=>{const l=a.value.trim();!l&&!t.optional||this.send({value:l},l||"—")};if(b.addEventListener("click",$),a.addEventListener("keydown",l=>{l.key==="Enter"&&$()}),n.append(a,b),this.foot.appendChild(n),t.optional){const l=document.createElement("button");l.className="skip",l.textContent="Skip this",l.addEventListener("click",()=>this.send({value:""},"—")),this.foot.appendChild(l)}a.focus()}this.brand()}bubble(e,t){const i=document.createElement("div");i.className=`msg ${e}`,i.textContent=t,this.log.appendChild(i),this.log.scrollTop=this.log.scrollHeight}typing(e){var i;if((i=this.log.querySelector(".typing"))==null||i.remove(),!e)return;const t=document.createElement("div");t.className="typing",t.setAttribute("aria-label","Typing"),t.innerHTML="<i></i><i></i><i></i>",this.log.appendChild(t),this.log.scrollTop=this.log.scrollHeight}error(e){const t=document.createElement("div");t.className="err",t.setAttribute("role","alert"),t.textContent=e,this.foot.prepend(t)}brand(){if(this.foot.querySelector(".brand"))return;const e=document.createElement("div");e.className="brand",e.textContent="Powered by Piotrack",this.foot.appendChild(e)}fail(){this.typing(!1);const e=this.config.fallback_contact;this.bubble("bot",e?`Sorry — our chat is temporarily unavailable. Please contact us at ${e} and we will get back to you.`:"Sorry — our chat is temporarily unavailable. Please use the contact details on this page and we will get back to you."),this.foot.innerHTML="",this.brand()}track(e){g("events",{type:e}).catch(()=>{})}}function C(o){return o.replace(/[&<>"']/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[e])}async function T(){if(k)try{const o=await g("config");if(!_(o.targeting))return;await P(o.targeting),new z(o).mount()}catch{}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",T):T()})();
